# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# def print_hi(name):
#     # Use a breakpoint in the code line below to debug your script.
#     print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.
#
#
# # Press the green button in the gutter to run the script.
# if __name__ == '__main__':
#     print_hi('PyCharm')

#具体思路看论文
import zipfile
import os

def watermark_of_word(resource,watermark): #dome不想写加密
    zipFile = zipfile.ZipFile(os.path.join(os.getcwd(), resource + ".docx"), "r") #以zip打开word得到xml
    Watermark = "<w:sectPr w:rsidR=\"" + "\"" + watermark + "\"" + "w:rsidSect =\"" + watermark + "\" >"
    zipFile.extract("word/document.xml")#解压
    file = open("word/document.xml", "r+", encoding='utf-8')
    file.seek(0, 0)
    string = file.read()
    start = len(string)  # 默认在文件尾
    strs = string.split("</w:sectPr>");#希望加载信息的模板位置
    text = strs[0] + Watermark + "</w:sectPr>" + strs[1]# 制作隐藏水印的xml格式
    file.seek(0, 0)
    file.write(text)
    file.closed

    zout = zipfile.ZipFile(resource+"_watermark.docx", 'w')  # 被写入对象
    zin = zipfile.ZipFile(resource+".docx", 'r')#读取对象
    file = open("word/document.xml", "rb")
    text = file.read()
    for file in zipFile.namelist():
        re_file = zin.read(file)
        if file != "word/document.xml":#如果不是目标文件直接复制
            zout.writestr(file, re_file)
        else:
            zout.writestr("word/document.xml", text)#是目标文件，将加好水印的目标文件写入
    zout.close()
    zin.close()

def watermark_of_ppt(resource,watermark): #dome不想写加密
    zipFile = zipfile.ZipFile(os.path.join(os.getcwd(), resource + ".pptx"), "r")
    Watermark = "<a: tblStylestyleId =\"{" + "\"" + watermark + "}\"" + "styleName =\"" + watermark + "\"/>"
    zipFile.extract("ppt/tableStyles.xml")
    file = open("ppt/tableStyles.xml", "r+", encoding='utf-8')
    file.seek(0, 0)
    string = file.read()
    start = len(string)  # 默认在文件尾
    strs = string.split("</a:tblStyleLst>");
    text = strs[0] + Watermark + "</a:tblStyleLst>" + strs[1]
    file.seek(0, 0)
    file.write(text)
    file.closed

    zout = zipfile.ZipFile(resource+"_watermark.pptx", 'w')  # 被写入对象
    zin = zipfile.ZipFile(resource+".pptx", 'r')
    file = open("ppt/tableStyles.xml", "rb")
    text = file.read()
    for file in zipFile.namelist():
        re_file = zin.read(file)
        if file != "ppt/tableStyles.xml":
            zout.writestr(file, re_file)
        else:
            zout.writestr("ppt/tableStyles.xml", text)
    zout.close()
    zin.close()

def watermark_of_excel(resource,watermark): #dome不想写加密
    zipFile = zipfile.ZipFile(os.path.join(os.getcwd(), resource + ".xlsx"), "r")
    Watermark = "< x14 : id> {" + watermark + "}" + "</ x14:id>"
    zipFile.extract("xl/styles.xml")
    file = open("xl/styles.xml", "r+", encoding='utf-8')
    file.seek(0, 0)
    string = file.read()
    start = len(string)  # 默认在文件尾
    strs = string.split("<extLst>");
    text = strs[0] + "<extLst>" + Watermark + strs[1]
    file.seek(0, 0)
    file.write(text)
    file.closed

    zout = zipfile.ZipFile(resource+"_watermark.xlsx", 'w')  # 被写入对象
    zin = zipfile.ZipFile(resource+".xlsx", 'r')
    file = open("xl/styles.xml", "rb")
    text = file.read()
    for file in zipFile.namelist():
        re_file = zin.read(file)
        if file != "xl/styles.xml":
            zout.writestr(file, re_file)
        else:
            zout.writestr("xl/styles.xml", text)
    zout.close()
    zin.close()


watermark_of_word("test", "nuaa")
watermark_of_ppt("test", "nuaa")
watermark_of_excel("test", "nuaa")

